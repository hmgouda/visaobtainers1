<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'ijas_visa');

/** MySQL database username */
define('DB_USER', 'ijas_visa');

/** MySQL database password */
define('DB_PASSWORD', 'ADt5bRN8te');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '7]_j8X1)b,RyYuQq<-_r;ufZ^zD-Q{aB(N;1N:AJt(#P498m*i%6o);lc{fm!apD');
define('SECURE_AUTH_KEY',  'dA&qJbZe|]KSOi6(;JQsjk<.NDj!$pmoUb^a+Y%fxv#]9-Y1n?44bvWBnVaAcqC.');
define('LOGGED_IN_KEY',    'HEN<zM{j9[K@K]GX=e0I$-yNwLXHu>`Yx+k =&U5:#N 1u{Jvx4:!_&42+Q9:WWq');
define('NONCE_KEY',        'X34VdWHhHj GfhsOI#?I=Z!e(R8$[kgcKmWs!Fj$i~ 3x<O^|2T!dA@%AnDvwv*w');
define('AUTH_SALT',        '@Tvy?C.jmXlQo&*0t>Sq<pv82?t4zAbnl;T456c3CB6sS};G_e3nF 9E%g.TLUg}');
define('SECURE_AUTH_SALT', 'oaYxE&sZP># %:{FOW}8sv:hMw_{QKhezbYCxL[4tcsHIl1A3Wa47c_H5j#3gZaD');
define('LOGGED_IN_SALT',   'u->@`hT2+u)Aj6Offvd_kiuU;vc9t}<2@(|CZ8kZ}8EMX*mx4s:o{@,qqZfBu55f');
define('NONCE_SALT',       '8oy0m7loYSyX%hH@v{q_VnlE>g})s8L^gkuR}@5x-4p+12ZYs6#iYVs%tLrRV{7L');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'vo_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
